package com.basic.coding.questions.set2;

public class Result_of_expression {

	public static void main(String[] args) {
		
		System.out.println("The result of"+
		"Expn: 7/4* 9/2 in terms of floating point value will be ");

		float a= 7/4.0f * 9/2.0f;
		
		System.out.println(a);
	}

}
