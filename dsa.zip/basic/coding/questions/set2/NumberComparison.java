package com.basic.coding.questions.set2;

import java.util.Scanner;

public class NumberComparison {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner sc = new Scanner(System.in);
	System.out.println("enter a num to test");
	int b=sc.nextInt();
	int a = 8;
	
	System.out.println("The entered the value is greater than 8: "+(b>8));
	}

}
